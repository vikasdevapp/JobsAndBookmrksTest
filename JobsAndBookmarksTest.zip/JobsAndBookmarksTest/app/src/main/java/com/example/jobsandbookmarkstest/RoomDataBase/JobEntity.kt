package com.example.jobsandbookmarkstest.RoomDataBase

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarked_jobs")
data class JobEntity(
    @PrimaryKey val id: Long,
    val title: String?,
    val companyName: String?,
    val jobLocationSlug: String?,
    val salaryMin: Long?,
    val salaryMax: Long?,
    val jobCategory: String?,
    val jobRole: String?,
    val createdOn: String?
)