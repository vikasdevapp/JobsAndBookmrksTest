package com.example.jobsandbookmarkstest.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.jobsandbookmarkstest.RoomDataBase.JobEntity
import com.example.jobsandbookmarkstest.databinding.ItemBookmarkedJobBinding

class BookmarkedJobsAdapter : ListAdapter<JobEntity, BookmarkedJobsAdapter.JobViewHolder>(JobDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val binding = ItemBookmarkedJobBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JobViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class JobViewHolder(private val binding: ItemBookmarkedJobBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(job: JobEntity) {
            binding.apply {
                jobTitle.text = job.title
                companyName.text = job.companyName
                jobLocation.text = job.jobLocationSlug
                salary.text = "${job.salaryMin} - ${job.salaryMax}"
                jobCategory.text = job.jobCategory
                jobRole.text = job.jobRole
                createdOn.text = job.createdOn
            }
        }
    }

    class JobDiffCallback : DiffUtil.ItemCallback<JobEntity>() {
        override fun areItemsTheSame(oldItem: JobEntity, newItem: JobEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: JobEntity, newItem: JobEntity): Boolean {
            return oldItem == newItem
        }
    }
}