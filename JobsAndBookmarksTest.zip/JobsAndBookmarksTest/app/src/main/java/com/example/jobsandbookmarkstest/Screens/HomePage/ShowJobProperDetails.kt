package com.example.jobsandbookmarkstest.Screens.HomePage

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.jobsandbookmarkstest.Model.JobsModelResponseData
import com.example.jobsandbookmarkstest.RoomDataBase.AppDatabase
import com.example.jobsandbookmarkstest.RoomDataBase.JobEntity
import com.example.jobsandbookmarkstest.databinding.ActivityShowJobProperDetailsBinding
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

class ShowJobProperDetails : AppCompatActivity() {

    private lateinit var binding:ActivityShowJobProperDetailsBinding
    private lateinit var data: JobsModelResponseData
    private lateinit var appDatabase: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityShowJobProperDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appDatabase = AppDatabase.getInstance(applicationContext)
        binding.showproperdetailsAppbar.appBarText.text="Job Proper Details"

        binding.showproperdetailsAppbar.backBtn.setOnClickListener {
            finish()
        }

        val reimbursementID = intent.getStringExtra("jobId")
        Log.d("Jobs", "Received JSON: $reimbursementID")

        if (!reimbursementID.isNullOrEmpty()) {
            val gson = Gson()
            try {
                data = gson.fromJson(reimbursementID, JobsModelResponseData::class.java)
                bindData()
                setupBookmarkButton()
            } catch (e: JsonSyntaxException) {
                Log.e("Jobs", "JSON parsing error: ${e.message}")
            }
        } else {
            Log.e("Jobs", "Invalid JSON format..")
        }
    }
    private fun formatDate(dateString: String): String {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX", Locale.US)
        return try {
            val date = inputFormat.parse(dateString)
            val outputFormat = SimpleDateFormat("dd MMM, yyyy", Locale.US)
            outputFormat.format(date ?: return "Invalid date")
        } catch (e: Exception) {
            Log.e("DateFormatting", "Error parsing date: ${e.message}")
            "Invalid date"
        }
    }
    private fun setupBookmarkButton() {
        binding.bookmarkthedetails.setOnClickListener {
            lifecycleScope.launch(Dispatchers.IO) {
                val jobEntity = JobEntity(
                    id = data.id ?: return@launch,
                    title = data.title,
                    companyName = data.companyName,
                    jobLocationSlug = data.jobLocationSlug,
                    salaryMin = data.salaryMin,
                    salaryMax = data.salaryMax,
                    jobCategory = data.jobCategory,
                    jobRole = data.jobRole,
                    createdOn = data.createdOn
                )
                appDatabase.jobDao().insertJob(jobEntity)
            }
        }
    }

    private fun bindData(){

        val noDataMessage = "No data available"

        binding.titleinputproperdet.text = data.title ?: noDataMessage
        binding.locationProperDet.text = data.jobLocationSlug ?: noDataMessage
        binding.salaryProperDet.text = if (data.salaryMin != null && data.salaryMax != null) {
            "${data.salaryMin} - ${data.salaryMax}"
        } else {
            noDataMessage
        }
        binding.phoneProperDet.text = data.whatsappNo ?: noDataMessage
        binding.companyNameProper.text = data.companyName ?: noDataMessage
        binding.jobcategoryProper.text = data.jobCategory ?: noDataMessage
        binding.roleProperDet.text = data.jobRole ?: noDataMessage
        binding.feeschargeProper.text = data.amount ?: noDataMessage
        binding.workingHoursProper.text = data.jobHours ?: noDataMessage
        binding.createdOnproper.text = data.createdOn?.let { formatDate(it) } ?: noDataMessage

    }
}