package com.example.jobsandbookmarkstest.RoomDataBase

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
abstract interface JobDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobEntity)

    @Query("SELECT * FROM bookmarked_jobs")
    suspend fun getAllBookmarkedJobs(): List<JobEntity>

    @Query("SELECT * FROM bookmarked_jobs WHERE id = :jobId")
    suspend fun getJobById(jobId: Long): JobEntity?

    @Delete
    suspend fun deleteJob(job: JobEntity)
}
